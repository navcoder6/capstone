export class IncidentModel{
    constructor(){

    }
    Id:number;

}